export const environment = {
  firebase: {
    apiKey: "AIzaSyA56jiM0ZDs-RwfOMnh6jmDyXgsNXyHBF4",
    authDomain: "proyectosemestralapp.firebaseapp.com",
    projectId: "proyectosemestralapp",
    storageBucket: "proyectosemestralapp.appspot.com",
    messagingSenderId: "41040211975",
    appId: "1:41040211975:web:98aa3c761e45e068ca3aa2",
    measurementId: "G-9G4D0955XJ"
  }
};
